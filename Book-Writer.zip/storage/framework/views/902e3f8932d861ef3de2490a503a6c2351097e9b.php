
<?php $__env->startSection('title', 'Update About'); ?>
<?php $__env->startPush('web-css'); ?>
    <style>
        ul li a {
            color: #000 !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid" id="Category">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fas fa-home"></i> <a class="<?php echo e(route('dashboard')); ?>" href="">Home</a> > Company Profile</span>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card my-2">
                    <div class="card-header d-flex justify-content-between">
                        <div class="table-head">
                            <i class="fas fa-edit"></i> Update Your About Information
                        </div>
                    </div>
                    
                    <div class="card-body table-card-body">
                        <div class="row">
                            <form method="post" action="<?php echo e(route('about.update', $about->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group row">
                                    <div class="col-sm-4">
                                        <label for="name" class="col-form-label">Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control shadow-none" name="name" id="name" value="<?php echo e($about->name); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="cover_letter" class="col-form-label">Cover Letter <span class="text-danger">*</span></label>
                                        <textarea name="cover_letter" class="form-control shadow-none" id="cover_letter" cols="3" rows="3"><?php echo e($about->cover_letter); ?></textarea>
                                        <?php $__errorArgs = ['cover_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="facebook" class="col-form-label">Facebook </label>
                                        <input type="url" class="form-control shadow-none" name="facebook" id="facebook" value="<?php echo e($about->facebook); ?>" placeholder="facebook url">
                                        <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="instagram" class="col-form-label">Instagram </label>
                                        <input type="url" class="form-control shadow-none" name="instagram" id="instagram" value="<?php echo e($about->instagram); ?>" placeholder="instagram url">
                                        <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="inputPassword" class="col-form-label">Image</label>
                                        <input type="file" name="image" class="form-control shadow-none" id="image" onchange="readURL(this)">
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        <div class="">
                                            <img src="#" id="previewImage" style="width: 100px; height: 80px; border: 1px solid #999; padding: 2px;" alt="">
                                        </div>

                                    </div>
                                    <div class="col-sm-4">
                                        <label for="biography" class="col-form-label">Biography <span class="text-danger">*</span></label>
                                        <textarea name="biography" class="form-control shadow-none" id="biography cols="3" rows="6"><?php echo e($about->biography); ?></textarea>
                                        <?php $__errorArgs = ['biography'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="twitter" class="col-form-label">Twitter </label>
                                        <input type="url" class="form-control shadow-none" name="twitter" id="twitter" value="<?php echo e($about->twitter); ?>" placeholder="twitter url">
                                        <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="google" class="col-form-label">Email </label>
                                        <input type="email" class="form-control shadow-none" name="google" id="google" value="<?php echo e($about->google); ?>" placeholder="Enter email">
                                        <?php $__errorArgs = ['google'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="inputPassword" class="col-form-label">Signature</label>
                                        <input type="file" name="signature" class="form-control shadow-none" id="signature" onchange="readSignature(this)">
                                        <?php $__errorArgs = ['signature'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        <div class="">
                                            <img src="#" id="previewSignature" style="width: 140px; height: 60px; border: 1px solid #999; padding: 2px;" alt="">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <label for="about_books" class="col-form-label">About Books </label>
                                        <textarea name="about_books" class="form-control shadow-none" id="about_books cols="3" rows="4" placeholder="Enter About Books"><?php echo e($about->about_books); ?></textarea>
                                        <?php $__errorArgs = ['about_books'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="want_meet" class="col-form-label">Meet Me? </label>
                                        <textarea name="want_meet" class="form-control shadow-none" id="want_meet cols="3" rows="4" placeholder="Want to meet?"><?php echo e($about->want_meet); ?></textarea>
                                        <?php $__errorArgs = ['want_meet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label for="inspiration" class="col-form-label">Inspiration </label>
                                        <textarea name="inspiration" class="form-control shadow-none" id="inspiration cols="3" rows="4" placeholder="Enter Inspiration"><?php echo e($about->inspiration); ?></textarea>
                                        <?php $__errorArgs = ['inspiration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <hr class="my-2">
                                <div class="clearfix">
                                    <div class="text-end m-auto">
                                        <button type="reset" class="btn btn-reset shadow-none">Reset</button>
                                        <button type="submit" class="btn btn-submit shadow-none">Update</button>
                                    </div>
                                </div>
                            </form> 
                        </div>
                         
                    </div>
                </div>  
            </div>
            
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#previewImage')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(80);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewImage").src="<?php echo e((!empty($about)) ? asset($about->image) : asset('no-image.jpg')); ?>";

        function readSignature(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#previewSignature')
                        .attr('src', e.target.result)
                        .width(160)
                        .height(60);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        document.getElementById("previewSignature").src="<?php echo e((!empty($about)) ? asset($about->signature) : asset('no-image.jpg')); ?>";
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Book-Writer\resources\views/admin/about.blade.php ENDPATH**/ ?>