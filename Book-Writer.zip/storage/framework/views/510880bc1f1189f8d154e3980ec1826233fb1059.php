<!-- footer start -->
<div class="footer">
    <div class="footer-one">
        <h1><?php echo e($content->name); ?></h1>
        <p><?php echo e($content->short_details); ?></p>
    </div>
    <div class="footer-two">
        <h3>Pages</h3>
        <p><a href="<?php echo e(route('about.me')); ?>">About</a></p>
        <p><a href="<?php echo e(route('category')); ?>">Categories</a></p>
        <p><a href="<?php echo e(route('shop')); ?>">Shop</a></p>
        <p><a href="<?php echo e(route('blogs')); ?>">Blog</a></p>
        <p><a href="<?php echo e(route('contact')); ?>">Contact</a></p>
    </div>
    <div class="footer-three">
        <h3>Newsletter</h3>
        <input type="text" placeholder="Your email address">
        <button><a href="#">Sing up</a></button>
    </div>
</div>
<!-- footer end -->
<?php /**PATH F:\xampp\htdocs\Book-Writer\resources\views/partials/web_footer.blade.php ENDPATH**/ ?>