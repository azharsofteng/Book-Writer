
<?php $__env->startSection('title', 'Book Details'); ?>
<?php $__env->startPush('web-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/details.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>
 <!-- full-book-details-page start -->
 <div class="full-book-details-page">
    <!-- book-details-head start -->
    <div class="book-details-head">
        <div class="book-details-head-img">
            <img src="<?php echo e(asset($product->image)); ?>" alt="book-1">
            
        </div>
        <div class="book-details-head-content">
            <h1><?php echo e($product->name); ?></h1>
            <p><?php echo e($product->short_details); ?></p>
            <div class="book-details-head-price">
                <?php if($product->discount > 0): ?>
                    <span>$<?php echo e($product->price - $product->discount); ?></span>
                    <del>$<?php echo e($product->price); ?></del>
                <?php else: ?>
                    <span>$<?php echo e($product->price); ?></span>
                <?php endif; ?>
            </div>
            <div class="full-inc-dec">
                <div class="inc-dec">
                    <button>-</button>
                    <span>1</span>
                    <button>+</button>
                </div>
                <div class="add-to-cart-btn">
                    <a href="<?php echo e(route('add.to.cart', $product->id)); ?>">Add to Cart</a>
                </div>
            </div>
            <button class="read-book">Read the Book</button>
        </div>
    </div>
    <!-- book-details-head end -->

    <!-- book-details-middle-content start -->
    <div class="book-details-middle-content">
        <div class="book-details-middle-content-1" style="text-align: justify;">
            <?php echo $product->details; ?>

        </div>
    </div>
    <!-- book-details-middle-content end -->

    <!-- writer start  -->
    <div class="writer">
        <div class="writer-img">
            <h1>Joyful and beautiful adventure. It will take you to landscapes never seen before!</h1>

            <div class="writer-content">
                <img src="<?php echo e(asset($product->writer_image)); ?>" alt="">
                <div>
                    <h3><?php echo e($product->writer); ?></h3>
                    <p>Writer</p>
                </div>
            </div>
        </div>
    </div>
    <!-- writer end  -->

    <!-- more book start -->
    <div class="more-book">
        <h1>More From <span><?php echo e($product->writer); ?></span></h1>
        <div class="more-book-section">
            <?php $__currentLoopData = $more_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <style>
                .image<?php echo e($key); ?>,
                .image<?php echo e($key); ?>::before {
                    background-image: url("<?php echo e(asset($book->image)); ?>");
                    background-size: cover;
                    background-repeat: no-repeat;
                }
            </style>
            <div class="book-card">
                <div class="container">
                    <div class="image image<?php echo e($key); ?>"></div>
                </div>
                <h2><?php echo e($book->name); ?></h2>
                <div class="span">
                    <?php if($book->discount > 0): ?>
                        <span>$<?php echo e($book->price - $book->discount); ?></span>
                        <del>$<?php echo e($book->price); ?></del>
                    <?php else: ?>
                        <span>$<?php echo e($book->price); ?></span>
                    <?php endif; ?>
                </div>
                <a class="add-to-cart" href="<?php echo e(route('add.to.cart', $book->id)); ?>">ADD TO CART</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- more book end -->

    <!-- Reviews start -->
    <div class="reviews">
        <h1>Reviews</h1>
        <p>There are no reviews yet.</p>
    </div>
    <!-- Reviews end -->

    <!-- add Reviews start -->
    <div class="add-reviews">
        <h1>Add a review</h1>
        <p>Your email address will not be published. Required fields are marked *</p>
    </div>
    
    <div class="rate">
        <select id="rate">
            <option value="rate" selected>Rate...</option>
            <option value="Perfect">Perfect</option>
            <option value="Good">Good</option>
            <option value="Average">Average</option>
            <option value="bad">Not that bad</option>
            <option value="poor">Very poor</option>
        </select>
    </div>
    <div class="review-details">
        <p>Your review *</p>
        <textarea name="" id="" cols="30" rows="10"></textarea>
        <p>Name *</p>
        <input type="text" name="" id="">
        <p>Email *</p>
        <input type="text" name="" id="">
    </div>
    <div class="checkbox">
        <input type="checkbox" name="" id="checkbox">
        <label for="checkbox">Save my name, email, and website in this browser for the next time I comment.</p>
    </div>
    <div class="sub-btn"><button>Submit</button></div>
    <!--add Reviews end -->

    <!-- Related products start -->
    <div class="related-products">
        <h1>Related products</h1>
        <div class="related-products-section">
            <?php $__currentLoopData = $cat_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <style>
                .image<?php echo e($key); ?>,
                .image<?php echo e($key); ?>::before {
                    background-image: url("<?php echo e(asset($item->image)); ?>");
                    background-size: cover;
                    background-repeat: no-repeat;
                }
            </style>
            <div class="book-card">
                <div class="container">
                    <div class="image image<?php echo e($key); ?>"></div>
                </div>
                <h2><?php echo e($item->name); ?></h2>
                <div class="span">
                    <?php if($item->discount > 0): ?>
                        <span>$<?php echo e($item->price - $item->discount); ?></span>
                        <del>$<?php echo e($item->price); ?></del>
                    <?php else: ?>
                        <span>$<?php echo e($item->price); ?></span>
                    <?php endif; ?>
                </div>
                <a class="add-to-cart" href="<?php echo e(route('add.to.cart', $item->id)); ?>">ADD TO CART</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- related products end -->
</div>
<!-- full-book-details-page end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Book-Writer\resources\views/pages/details.blade.php ENDPATH**/ ?>