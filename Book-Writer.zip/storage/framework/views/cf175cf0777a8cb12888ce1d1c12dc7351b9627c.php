
<?php $__env->startSection('title', 'Shop'); ?>
<?php $__env->startPush('web-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/shop.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>
 <!-- shop start -->
 <div class="shop">
    <!-- shop-head start -->
    <div class="shop-head">
        <div class="shop-head-content">
            <h1>Shop</h1>
            <p>Browse Our Fine Book Collection</p>
        </div>
    </div>
    <!-- shop-head end -->
    <div class="shop-main-content">
        
        <div class="shop-book">
            <div class="books">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <style>
                    .image<?php echo e($key); ?>,
                    .image<?php echo e($key); ?>::before {
                        background-image: url("../<?php echo e($book->image); ?>");
                        background-size: cover;
                        background-repeat: no-repeat;
                    }
                </style>
                <div class="book-card">
                    <a href="<?php echo e(route('book.details', $book->slug)); ?>">
                        <div class="container">
                            <div class="image image<?php echo e($key); ?>"></div>
                        </div>
                    </a>
                    <a href="<?php echo e(route('book.details', $book->slug)); ?>">
                        <h2><?php echo e($book->name); ?></h2>
                    </a>
                    <div class="span">
                        <?php if($book->discount > 0): ?>
                        <span>$<?php echo e($book->price - $book->discount); ?></span>
                        <del>$<?php echo e($book->price); ?></del>
                        <?php else: ?>
                        <span>$<?php echo e($book->price); ?></span>
                        <?php endif; ?>
                    </div>
                    <a class="add-to-cart" href="<?php echo e(route('add.to.cart', $book->id)); ?>">ADD TO CART</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="book-card">
                    <a href="./bookDetailsPage.html">
                        <div class="container">
                            <div class="image"></div>
                        </div>
                    </a>
                    <a href="./bookDetailsPage.html">
                        <h2>Glittering Stars</h2>
                    </a>
                    <div class="span">
                        <span>$12.00</span>
                        <del>$15.00</del>
                    </div>
                    <a class="add-to-cart" href="#">ADD TO CART</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php echo e($products->links('partials.custom-pagination')); ?>

        
    </div>
</div>
<!-- shop end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Book-Writer\resources\views/pages/shop.blade.php ENDPATH**/ ?>