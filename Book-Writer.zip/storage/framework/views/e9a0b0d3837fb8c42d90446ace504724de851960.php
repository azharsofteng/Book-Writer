
<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startPush('web-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/blog.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>
<!-- blog start -->
<div class="blog">
    <h1>Blog</h1>
    <div class="full-blog">
        <div class="left-blog">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="left-full-blog">
                <img src="<?php echo e(asset($blog->image)); ?>" alt="">
                <div class="left-blog-content">
                    <div class="blog-name-date">
                        <a href="#">
                            <h1><?php echo e($blog->title); ?></h1>
                        </a>
                        <p><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($blog->date))->format('F, d Y')); ?></p>
                    </div>
                    <hr>
                    <div class="blog-desc">
                        <?php echo Str::limit($blog->description, 200); ?>

                    </div>
                    <div class="left-blog-footer">
                        <a href="#"><button>Read More</button></a>
                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


        <div class="right-blog">
            
            <input type="text" placeholder="Search...">
            <?php if($book): ?>
            <div class="right-blog-book">
                <div>
                    <a href="#">
                        <h4><?php echo e($book->name); ?></h4>
                    </a>
                    <?php if($book->discount > 0): ?>
                        <span>$<?php echo e($book->price - $book->discount); ?></span>
                        <del>$<?php echo e($book->price); ?></del>
                    <?php else: ?>
                        <span>$<?php echo e($book->price); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <img src="<?php echo e(asset($book->image)); ?>" alt="book">
                </div>
            </div>
            <?php endif; ?>
            <div class="blog-twitter">
                <h1>Twitter</h1>
                <div class="blog-twitter-content">
                    <p><a href="#">@delimitedIT</a> Hello, Can you please write us through the Support tab on
                        ThremeForest and also include a link to you…</p>
                    <a href="#"> https://t.co/T8aUp6NSMb</a>
                    <a href="#">153 days ago</a>
                </div>
                <div class="blog-twitter-content">
                    <p><a href="#">@delimitedIT</a> Hello, Can you please write us through the Support tab on
                        ThremeForest and also include a link to you…</p>
                    <a href="#"> https://t.co/T8aUp6NSMb</a>
                    <a href="#">153 days ago</a>
                </div>
                <div class="blog-twitter-content">
                    <p><a href="#">@delimitedIT</a> Hello, Can you please write us through the Support tab on
                        ThremeForest and also include a link to you…</p>
                    <a href="#"> https://t.co/T8aUp6NSMb</a>
                    <a href="#">153 days ago</a>
                </div>
                <div class="blog-twitter-content">
                    <p><a href="#">@delimitedIT</a> Hello, Can you please write us through the Support tab on
                        ThremeForest and also include a link to you…</p>
                    <a href="#"> https://t.co/T8aUp6NSMb</a>
                    <a href="#">153 days ago</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- blog end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Book-Writer\resources\views/pages/blog.blade.php ENDPATH**/ ?>