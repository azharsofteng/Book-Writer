
<?php $__env->startSection('title', 'Product Entry'); ?>
<?php $__env->startPush('admin-css'); ?>
   <style>
        .ck.ck-editor__main>.ck-editor__editable{
            height: 300px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid" id="Product">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fas fa-home"></i> <a class="" href="<?php echo e(route('dashboard')); ?>">Home</a> > Product</span>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card my-2">
                    <div class="card-header d-flex justify-content-between">
                        <?php if(isset($product)): ?>
                            <div class="table-head"><i class="fa fa-edit"></i> Product Upate</div>
                        <?php else: ?>
                            <div class="table-head"><i class="fab fa-bandcamp"></i> Product Entry</div>
                        <?php endif; ?>
                        
                    </div>
                    
                    <div class="card-body table-card-body">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <form id="form" method="post" action="<?php echo e(isset($product) ? route('product.update', $product->id) : route('product.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group row">
                                <div class="col-lg-4 col-md-6">
                                    <label for="name" class="col-form-label">Name <span class="text-danger">*</span></label>
                                    <input type="text" name="name" id="name" value="<?php echo e(isset($product) ? $product->name : old('name')); ?>" class="form-control shadow-none form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label for="price" class="col-form-label mt-1">Price</label>
                                    <input type="number" step="0.00" name="price" id="price" value="<?php echo e(isset($product) ? $product->price : old('price')); ?>" class="form-control shadow-none form-control-sm <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mt-1">
                                </div>

                                <div class="col-lg-4 col-md-6">
                                    <label for="category_id" class="col-form-label">Category <span class="text-danger">*</span></label>
                                    <select name="category_id" class="form-control shadow-none <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category_id">
                                        <option value="">--select category--</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e(($item->id == @$product->category_id) ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <label for="discountPrice" class="col-form-label mt-1">Discount(%)</label>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input type="number" oninput="Discount()" id="percent"  class="form-control shadow-none mt-1">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" name="discount" id="discountPrice" value="<?php echo e(isset($product) ? $product->discount : old('discount')); ?>" class="form-control shadow-none mt-1" readonly>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-6">
                                    <label for="short_details" class="col-form-label">Short Details</label>
                                    <textarea name="short_details" class="form-control shadow-none form-control-sm" id="short_details" cols="5" rows="5" placeholder="Enter short details"><?php echo e(isset($product) ? $product->short_details : ''); ?></textarea>
                                </div>

                                <div class="col-lg-4 col-md-6">
                                    <label for="image" class="col-form-label">Image <span class="text-danger">*</span></label>
                                    <input type="file" name="image" class="form-control shadow-none <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" onchange="readURL(this);">
                                    
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div>
                                        <img src="<?php echo e((!empty(@$product)) ? asset(@$product->image) : asset('no-image.jpg')); ?>" id="previewImage" style="width: 100px; height: 100px; border: 1px solid #999; padding: 2px;" alt="">
                                    </div>
                                    <label for="writer" class="col-form-label">Writer <span class="text-danger">*</span></label>
                                    <input type="text" name="writer" id="writer" value="<?php echo e(isset($product) ? $product->writer : old('writer')); ?>" class="form-control shadow-none form-control-sm <?php $__errorArgs = ['writer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter writer">
                                    <?php $__errorArgs = ['writer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <label for="writer_image" class="col-form-label">Writer Image <span class="text-danger">*</span></label>
                                    <input type="file" name="writer_image" class="form-control shadow-none <?php $__errorArgs = ['writer_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="writer_image" onchange="readWriterURL(this);">
                                    
                                    <?php $__errorArgs = ['writer_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div>
                                        <img src="<?php echo e((!empty(@$product)) ? asset(@$product->writer_image) : asset('no-image.jpg')); ?>" id="previewWriterImage" style="width: 100px; height: 80px; border: 1px solid #999; padding: 2px;" alt="">
                                    </div>
                                    <label for="is_feature" class="mt-1"><input type="checkbox" name="is_feature" value="1" id="is_feature"> Is Feature</label>
                                </div>
                                <div class="col-lg-8 col-md-6">
                                    <label for="Details" class="col-form-label">Details</label>
                                    <textarea name="details" class="form-control shadow-none form-control-sm" id="Details" cols="5" rows="5"><?php echo e(isset($product) ? $product->details : ''); ?></textarea>
                                </div>
                            </div>
                            <hr class="my-2">
                            <div class="clearfix">
                                <div class="text-end m-auto">
                                    <button type="reset" class="btn btn-reset shadow-none">Reset</button>
                                    <button type="submit" class="btn btn-submit shadow-none">Save</button>
                                </div>
                            </div>
                        </form>  
                    </div>
                </div>  
            </div>
            <div class="col-lg-12 mt-2">
                <div class="card my-2">
                    <div class="card-header d-flex justify-content-between">
                        <div class="table-head"><i class="fas fa-table me-1"></i> Products List</div>
                        <div class="float-right">
                          
                        </div>
                    </div>
                    <div class="card-body table-card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered text-center" id="datatablesSimple" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Discount</th>
                                        <th>Short Details</th>
                                        <th>Writer</th>
                                        <th>Writer Image</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->category->name); ?></td>
                                        <td><?php echo e($item->price); ?></td>
                                        <td><?php echo e($item->discount); ?></td>
                                        <td><?php echo e(Str::limit($item->short_details, 50, '...')); ?></td>
                                        <td><?php echo e($item->writer); ?></td>
                                        <td><img src="<?php echo e(asset($item->writer_image)); ?>" width="40" height="40" alt=""></td>
                                        <td><img src="<?php echo e(asset($item->image)); ?>" width="40" height="40" alt=""></td>
                                        <td>
                                            <a href="<?php echo e(route('product.edit', $item->id)); ?>" class="btn btn-edit edit-item"><i class="fas fa-edit"></i></a>

                                            <button type="submit" class="btn btn-delete shadow-none" onclick="deleteProduct(<?php echo e($item->id); ?>)"><i class="fa fa-trash"></i></button>
                                            <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('product.delete',$item->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/ckeditor.js')); ?>"></script>
    <script>
        // ck editor 
        ClassicEditor
            .create( document.querySelector( '#Details' ) )
            .catch( error => {
                console.error( error );
            });
        
        // image preview
        function readURL(input){
            if (input.files && input.files[0]) {
                var reader    = new FileReader();
                reader.onload = function(e){
                    $('#previewImage').attr('src',e.target.result).width(100).height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        function readWriterURL(input){
            if (input.files && input.files[0]) {
                var reader    = new FileReader();
                reader.onload = function(e){
                    $('#previewWriterImage').attr('src',e.target.result).width(100).height(80);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // product delete
        function deleteProduct(id) {
            swal({
                title: 'Are you sure?',
                text: "You want to Delete this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === swal.DismissReason.cancel
                ) {
                    swal(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }

        // Discount calculate
        function Discount() {
            let price = document.getElementById("price").value;
            var percent = document.getElementById("percent").value;
            var discountPrice = parseFloat(price * percent) / 100;
            if (price == '') {
                alert('Please Enter Product Price First');
                document.getElementById("percent").value = 0;
                return; 
            }
            if(percent == '' || percent == 0) {
                document.getElementById("discountPrice").value = 0;
                return;
            }
            document.getElementById("discountPrice").value = discountPrice.toFixed(2);
        }

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/admin/product/index.blade.php ENDPATH**/ ?>