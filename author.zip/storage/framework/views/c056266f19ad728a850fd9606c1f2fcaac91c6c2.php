
<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('customer'); ?>
<div class="cart-section py-3">
    <div class="container mt-3">
        <div class="section-header">
            <h2>Your Cart</h2>
            <div class="line"></div>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12 col-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered text-center">
                    <thead class="">
                        <th>Sl</th>
                        <th colspan="2">Discription</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $total = 0 ?>
                        <?php if(session('cart')): ?>
                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $total += $product['price'] * $product['quantity'] ?>
                            <tr data-id="<?php echo e($id); ?>">
                                <td class="text-center"><?php echo e(++$id); ?></td>
                                <td width="60">
                                    <img height="30" src="<?php echo e(asset($product['image'])); ?>" class="cart-image">
                                </td>
                                <td><?php echo e($product['name']); ?></td>
                                <td class="text-right"><?php echo e($product['price']); ?></td>
                                <td width="8%" class="text-center" data-th="Quantity">
                                    <input style="height: 30px;"  type="number" value="<?php echo e($product['quantity']); ?>" class="form-control quantity update-cart" />
                                </td>
                                <td class="text-right"><?php echo e($product['price'] * $product['quantity']); ?></td>
                                <td class="text-center">
                                    <a href="" class=" btn-sm btn-danger btn-sm remove-from-cart"><i class="fa  fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <tr>
                            <td colspan="6" class="text-end">Sub Total :</td>
                            <td class="text-center"><?php echo e($total); ?> tk</td>
                        </tr>
                        <td colspan="7" class="text-end" style="padding:12px 10px !important">
                            <a href="<?php echo e(route('home')); ?>" class="continue_shopping btn-dark shadow-none"> < Continue Shopping</a>
                            <?php if(Auth::guard('customer')->check()): ?>
                                <a href="<?php echo e(route('checkout.cart')); ?>" class="checkout mx-2 shadow-none">Checkout</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('customer.login')); ?>" class="checkout mx-2 shadow-none">Checkout</a>
                            <?php endif; ?>
                        </td>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('partials.web_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customer-js'); ?>
<script type="text/javascript">
  
    $(".update-cart").change(function (e) {
        e.preventDefault();
  
        var ele = $(this);
        
        $.ajax({
            url: '<?php echo e(route('update.cart')); ?>',
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>', 
                id: ele.parents("tr").attr("data-id"), 
                quantity: ele.parents("tr").find(".quantity").val()
            },
            success: function (response) {
               window.location.reload();
            }
        });
    });
  
    $(".remove-from-cart").click(function (e) {
        e.preventDefault();
  
        var ele = $(this);
  
        if(confirm("Are you sure want to remove?")) {
            $.ajax({
                url: '<?php echo e(route('remove.from.cart')); ?>',
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', 
                    id: ele.parents("tr").attr("data-id")
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        }
    });
    
    $("document").ready(function(){
        setTimeout(function(){
        $("div.alert").remove();
        }, 3000 ); // 5 secs
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('pages.customer.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/pages/cart.blade.php ENDPATH**/ ?>