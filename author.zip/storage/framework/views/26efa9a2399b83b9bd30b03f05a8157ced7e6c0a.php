
<?php $__env->startSection('title', 'Order List'); ?> 
<?php $__env->startPush('admin-css'); ?>
    <style>
        .nav-tabs .nav-item {
            background-color: #1C3C72;
            border-right: 1px solid #fff;
        }
        .nav-tabs .nav-link {
            color: #fff;
        }
        .nav-tabs .nav-link:hover {
            color: #fff;
        }
        .btn-order {
            padding: 3px 7px !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid mt-2" id="root">
        <div class="row justify-content-center">
            <div class="col-md-12 pl-0">
                        
                <div class="card card-table">
                    <div class="card-header d-flex justify-content-between">
                        <h5><i class="fas fa-list-alt mr-1"></i> All Order List</h5>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-sm">Dashboard</a>
                    </div>
                    <div class="card-body">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger mt-2 col-md-6"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success mt-2 col-md-6"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <ul class="nav nav-tabs mb-2" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true">Pending</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#confirm" type="button" role="tab" aria-controls="confirm" aria-selected="false">Confirm</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#process" type="button" role="tab" aria-controls="process" aria-selected="false">Process</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#Shipping" type="button" role="tab" aria-controls="Shipping" aria-selected="false">Shipping</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#Delivered" type="button" role="tab" aria-controls="Delivered" aria-selected="false">Delivered</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#Cancel" type="button" role="tab" aria-controls="Cancel" aria-selected="false">Cancel</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pendingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td><a class="badge bg-danger ">Pending</a></td>
                                                <td>
                                                    <a href="<?php echo e(route('confirm.order',$item->id)); ?>" class="btn btn-primary btn-order shadow-none" title="Confirm Order"><i class="fas fa-check-circle"></i></a>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm shadow-none"><i class="fa fa-file-pdf"></i></a>
                                                    <button type="submit" class="btn btn-danger btn-sm shadow-none" onclick="deleteOrder(<?php echo e($item->id); ?>)"><i class="fa fa-trash"></i></button>
                                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('order.cancel', $item->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="confirm" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $confirmOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td><a class="badge bg-success">Confirm</a></td>
                                                <td>
                                                    <a href="<?php echo e(route('process.order',$item->id)); ?>" class="btn btn-success btn-order" title="Process Order"><i class="fas fa-check-circle"></i></a>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-file-pdf"></i></a>
                                                    <button type="submit" class="btn btn-danger btn-sm" onclick="deleteOrder(<?php echo e($item->id); ?>)"><i class="fa fa-trash"></i></button>
                                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('order.cancel', $item->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="process" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $processOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td><a class="badge bg-info">Process</a></td>
                                                <td>
                                                    <a href="<?php echo e(route('shipping.order',$item->id)); ?>" class="btn btn-warning btn-order shadow-none" title="Shipping Order"><i class="fas fa-dolly"></i></a>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm shadow-none"><i class="fa fa-file-pdf"></i></a>
                                                    <button type="submit" class="btn btn-danger btn-sm shadow-none" onclick="deleteOrder(<?php echo e($item->id); ?>)"><i class="fa fa-trash"></i></button>
                                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('order.cancel', $item->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Shipping" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $shippingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td><a class="badge bg-primary">Shipping</a></td>
                                                <td>
                                                    <a href="<?php echo e(route('delivered.order',$item->id)); ?>" class="btn btn-dark btn-order shadow-none" title="Delivered Order"><i class="fas fa-truck"></i></a>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm shadow-none"><i class="fa fa-file-pdf"></i></a>
                                                    <button type="submit" class="btn btn-danger btn-sm shadow-none" onclick="deleteOrder(<?php echo e($item->id); ?>)"><i class="fa fa-trash"></i></button>
                                                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('order.cancel', $item->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Delivered" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $deliveredOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td><a class="badge bg-success">Delivered</a></td>
                                                <td>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm shadow-none"><i class="fa fa-file-pdf"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php if(isset($cancelOrders)): ?>
                            <div class="tab-pane fade" id="Cancel" role="tabpanel" aria-labelledby="contact-tab" tabindex="0">
                                <div class="table-responsive">
                                    <table class="table table-bordered text-center" id="" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>SL</th>
                                                <th>Date</th>
                                                <th>Customer</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $cancelOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($item->created_at->format('j F Y')); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td><?php echo e($item->sub_total); ?></td>
                                                <td class="badge bg-danger">Cancel</td>
                                                <td>
                                                    <a href="<?php echo e(route('invoice', $item->id)); ?>" class="btn btn-info btn-sm shadow-none"><i class="fa fa-file-pdf"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin-js'); ?>
<script src="https://unpkg.com/sweetalert2@7.19.1/dist/sweetalert2.all.js"></script>
<script type="text/javascript">
    function deleteOrder(id) {
        swal({
            title: 'Are you sure?',
            text: "You want to Cancel this Order!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Cancel it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger',
            buttonsStyling: false,
            reverseButtons: true
        }).then((result) => {
            if (result.value) {
                event.preventDefault();
                document.getElementById('delete-form-'+id).submit();
            }
        })
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/admin/order/list.blade.php ENDPATH**/ ?>