
<?php $__env->startSection('title', 'Change Password'); ?>
<?php $__env->startSection('customer'); ?>
<section id="dashboard">
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-3">
                <?php echo $__env->make('pages.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-7">
                <div class="customer_profile">
                    <h4 class="text-black fw-bold text-center mb-3"><i class="fa fa-key" aria-hidden="true"></i> Update Password</h4>
                    <div class="customer_form">
                        <form action="<?php echo e(route('customer.password.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row mb-2">
                                <label for="inputPassword" class="col-sm-3 col-form-label">Old Password</label>
                                <div class="col-sm-9">
                                    <input type="password" name="old_password" value="<?php echo e(old('old_password')); ?>" class="form-control shadow-none" id="" placeholder="Old Password">
                                    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="form-group row mb-2">
                                <label for="inputPassword" class="col-sm-3 col-form-label">New Password</label>
                                <div class="col-sm-9">
                                    <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control shadow-none" id="" placeholder="New Password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="form-group row mb-2">
                                <label for="inputPassword" class="col-sm-3 col-form-label">Confirm Password</label>
                                <div class="col-sm-9">
                                    <input type="password" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" class="form-control shadow-none" id="password_confirmation" placeholder="Confirm Password">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            <div class="form-group row">
                                <label for="inputPassword" class="col-sm-3 col-form-label"></label>
                                <div class="col-sm-9 d-flex justify-content-end">
                                    <button class="btn btn-success shadow-none" type="submit">Update change</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.customer.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/pages/customer/change_password.blade.php ENDPATH**/ ?>