
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startPush('web-css'); ?>
    
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>
<!-- all categories start -->
<div class="allcategories">
    <div class="categories-top">
        <h1>Book Shelves <br> <span>with</span> <br> Our Categories </h1>
    </div>
    <div class="categorise-content">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="categorise-blog">
            <?php if($loop->odd): ?> 
            <div>
                <h1><?php echo e($category->name); ?></h1>
                <span><?php echo e($category->title); ?></span>
                <p><?php echo e($category->description); ?></p>
            </div>
            <?php else: ?> 
            <div>
                <img src="<?php echo e($category->image); ?>" alt="">
            </div>
            <?php endif; ?>

            <?php if($loop->odd): ?> 
            <div>
                <img src="<?php echo e($category->image); ?>" alt="">
            </div>
            <?php else: ?> 
            <div>
                <h1><?php echo e($category->name); ?></h1>
                <span><?php echo e($category->title); ?></span>
                <p><?php echo e($category->description); ?></p>
            </div>
            <?php endif; ?>
     
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- all categories end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/pages/category.blade.php ENDPATH**/ ?>