<footer class="py-2 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted common-text">Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e($content->name); ?></div>
            <div class="common-text text-muted">
                Develop By -
                <a class="text-decoration-none" target="_blank" href="https://zealtechbd.com/">Zealtech BD.</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\author\resources\views/partials/footer.blade.php ENDPATH**/ ?>