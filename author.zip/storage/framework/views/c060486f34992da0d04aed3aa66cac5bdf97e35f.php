<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <title>Author | Customer Login</title>
        <link rel="icon" href="<?php echo e(asset('images/M-favicon.png')); ?>" type="image/gif" sizes="16x16">
        <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('css/materialdesignicons.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-4.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" />
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center d-flex align-items-center min-vh-100 py-3 py-md-0">
                <div class="col-md-8">
                    <div class="login-area">
                        <h4 class="heading">Create an Account</h4>
                        <form method="POST" action="<?php echo e(route('customer.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name">Full Name <span class="text-danger">*</span> </label>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> shadow-none" id="name" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email">E-Mail Address <span class="text-danger">*</span></label>
                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> shadow-none" id="email" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="phone">Phone Number </label>
                                    <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control shadow-none" id="phone" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control shadow-none" id="address" />
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="password">Password <span class="text-danger">*</span> </label>
                                    <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> shadow-none" id="password" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="password_confirmation">Confirm Password <span class="text-danger">*</span> </label>
                                    <input type="password" name="password_confirmation" value="" class="form-control shadow-none" id="password_confirmation" />
                                </div>
                            </div>
        
                            <div class="clearfix mt-1">
                                <div class="float-md-left">
                                    <button type="submit" class="btn btn-outline-info">Sign Up</button>
                                    <button type="reset" class="btn btn-dark">Reset</button>
                                </div>
                                <div class="float-md-right mt-2 d-block">Already have an account? <a href="<?php echo e(route('customer.login')); ?>">Sign in</a></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>        
    </body>
</html>
<?php /**PATH C:\laragon\www\author\resources\views/auth/customer/registration.blade.php ENDPATH**/ ?>