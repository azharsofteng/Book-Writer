
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startPush('web-css'); ?>
    <style>
        header {
            background: url('<?php echo e($banner->image); ?>') no-repeat center center;
            background-size: cover;
            height: 100vh;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('web-content'); ?>
<!-- Nav-Bar End-->
<header>
    <!-- head-title start -->
    <div class="head-title">
        <h1>Hello <br> I'm <span>Dr. Iftekhar Ahmed Shams</span></h1>
        <h6><?php echo e($banner->title); ?></h6>
        <p><?php echo e($banner->sub_title); ?></p>
        <div class="head-btn">
            <button><a href="<?php echo e($banner->btn_url); ?>" class="head-btn1">Latest Books</a></button>
            
        </div>
    </div>
    <!-- head-title end -->
</header>
<!-- midel-content-one start-->
<div class="midel-content-one">
    <img src="images/black-leaf.png" alt="black-leaf">
    <h5>"Every day is a journey and the journey itself is home."</h5>
    <p>MATSU BASHIO</p>
</div>
<!-- midel-content-one end -->

<!-- book-list start -->
<div class="book-list">
    <div class="books">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <style>
            .image<?php echo e($key); ?>,
            .image<?php echo e($key); ?>::before {
                background-image: url("<?php echo e($book->image); ?>");
                background-size: cover;
                background-repeat: no-repeat;
            }
        </style>
        <div class="book-card">
            <div class="container">
                <a href="<?php echo e(route('book.details', $book->slug)); ?>">
                    <div class="image image<?php echo e($key); ?>" ></div>
                </a>
            </div>
            <h2><?php echo e($book->name); ?></h2>
            <div class="span">
                <?php if($book->discount > 0): ?>
                <span>$<?php echo e($book->price - $book->discount); ?></span>
                <del>$<?php echo e($book->price); ?></del>
                <?php else: ?>
                <span>$<?php echo e($book->price); ?></span>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('add.to.cart', $book->id)); ?>">ADD TO CART</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="book-card">
            <div class="container">
                <div class="image image2"></div>
            </div>
            <h2>Little Explorers</h2>
            <div class="span">
                <span>$11.00</span>
                <del>$13.00</del>
            </div>
            <a href="#">ADD TO CART</a>
        </div>
        <div class="book-card">
            <div class="container">
                <div class="image image3"></div>
            </div>
            <h2>Magic Corner</h2>
            <div class="span">
                <span>$15.00</span>
                <del>$16.00</del>
            </div>
            <a href="#">BUY PRODUCT</a>
        </div>
        <?php endif; ?>
    </div>
    <div class="books-library">
        <div>
            <p><?php echo e($new_book->name); ?>.</p>
            <h1>Newest Books in <br> Our Library</h1>
            <p><?php echo e(Str::limit($new_book->short_details, 200, '...')); ?></p>
            <button><a href="<?php echo e(route('shop')); ?>">View All Books</a></button>
        </div>
    </div>
</div>
<!-- book-list end -->

<!-- best-sellers start -->
<div class="hr">
    <div class="hr2"></div>
</div>
<div class="best-sellers">
    <div>
        <h1>Shop Our <br> Best Sellers</h1>
        <p>See the Books People Read the Most</p>
    </div>
    <div>
        <p class="best-sellers-content">Wouldn’t you like to get away? Sometimes you want to go where everybody
            knows your name. And they’re always glad you came. Makin their way the only way they know how.</p>
    </div>
</div>
<!-- best-sellers end -->

<!-- owl-carousel start -->
<div class="owl-carousel owl-theme">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="item">
    <style>
        .image<?php echo e($key); ?>,
        .image<?php echo e($key); ?>::before {
            background-image: url("<?php echo e($item->image); ?>");
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
        <div class="container">
            <div class="image image<?php echo e($key); ?>"></div>
        </div>
        <div class="owl-carousel-content">
            <h2><?php echo e($item->name); ?></h2>
            <div class="span">
                <?php if($item->discount > 0): ?>
                    <span>$<?php echo e($item->price -  $item->discount); ?></span>
                    <del>$<?php echo e($item->price); ?></del>
                <?php else: ?>
                    <span>$<?php echo e($item->price); ?></span>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('product.checkout', $item->id)); ?>">BUY PRODUCT</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="item">
        <div class="container">
            <div class="image"></div>
        </div>
        <div class="owl-carousel-content">
            <h2>Glittering Stars</h2>
            <div class="span">
                <span>$11.00</span>
                <del>$16.00</del>
            </div>
            <a href="#">BUY PRODUCT</a>
        </div>
    </div>
    <div class="item">
        <div class="container">
            <div class="image image2"></div>
        </div>
        <div class="owl-carousel-content">
            <h2>Little Explorers</h2>
            <div class="span">
                <span>$11.00</span>
                <del>$16.00</del>
            </div>
            <a href="#">BUY PRODUCT</a>
        </div>
    </div>
    <?php endif; ?>
</div>
<!-- owl-carousel end -->

<!-- Featured Book start -->
<?php if(isset($featured)): ?>
<div class="featured-book">
    <style>
        .image7,
        .image7::before {
            background-image: url('<?php echo e($featured->image); ?>');
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
    <div class="featured-book-content">
        <p><?php echo e($featured->name); ?></p>
        <h1>Featured Book</h1>
        <p>THE STORY</p>
        <p><?php echo e($featured->short_details); ?></p>
        <p>ABOUT SKY KINGDOM</p>
        <div>
            <?php echo Str::limit($featured->details, 350, '...'); ?>

        </div>
        <button><a href="<?php echo e(route('book.details', $featured->slug)); ?>"> Learn More</a></button>
    </div>
    <div class="featured-book-img">
        
        <div class="featured-book-card">
            <div class="container featured-book-img-con">
                <div class="image image7"></div>
            </div>
            <h2><?php echo e($featured->name); ?></h2>
            <div class="span">
                <?php if($featured->discount > 0): ?>
                <span>$<?php echo e($featured->price - $featured->discount); ?></span>
                <del>$<?php echo e($featured->price); ?></del>
                <?php else: ?>
                <span>$<?php echo e($featured->price); ?></span>
                <?php endif; ?>
                
            </div>
            <div class="featured-book-img-con-btn">
                <a href="<?php echo e(route('book.details', $featured->slug)); ?>" class="featured-book-img-con-btn1">Read the Book</a>
                <a href="<?php echo e(route('add.to.cart', $featured->id)); ?>" class="featured-book-img-con-btn2">ADD TO CART</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!-- Featured Book end -->

<!-- Product-content start -->
<div class="product-content">
    <div class="product-card shipping">
        <p class="head-p">FREE SHIPPING</p>
        <p class="content-p">Check out free shipping options and benefits for the holidays</p>
    </div>
    <div class="product-card delivery">
        <p class="head-p">24 HOURS DELIVERY</p>
        <p class="content-p">Check out free shipping options and benefits for the holidays</p>
    </div>
    <div class="product-card returns">
        <p class="head-p">FREE RETURNS</p>
        <p class="content-p">Check out free shipping options and benefits for the holidays</p>
    </div>
</div>
<!-- Product-content end -->

<!-- Fantasy-Reading-Adventure start -->
<div class="fantasy-reading-adventure">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="fantasy">
        <a href="<?php echo e(route('shop', $category->id)); ?>">
            <div class="fantasy-img">
                <img src="<?php echo e(asset($category->image)); ?>" alt="">
            </div>
            <div class="fantasy-img-content">
                <h1><?php echo e($category->name); ?></h1>
                <p><?php echo e($category->products->count()); ?> Items</p>
            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
</div>
<!-- Fantasy-Reading-Adventure end -->


<!-- signature start -->
<div class="signature start">
    <p>Created with only one goal in mind.To be your <b> <u> only choice </u> </b> <br> for the web presence of your
        book.</p>
    <img src="images/signature.png" alt="">
</div>
<!-- signature end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/pages/home.blade.php ENDPATH**/ ?>