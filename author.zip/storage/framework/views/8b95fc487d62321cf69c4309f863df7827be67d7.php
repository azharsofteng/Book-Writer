
<?php $__env->startSection('title', 'Order Invoice'); ?> 
<?php $__env->startPush('admin-css'); ?>
<style>
    .container {
        width: 100%;
        margin: 0px auto;
    }
    .custom-row {
        width: 100%;
        display: block;
    }

    .print-btn a{
        background: #CFD8DC;
        display: inline-block;
        padding: 3px 13px;
        border-radius: 5px;
        color: #000 !important;
    }
    .print-btn a:hover {
        background: #B0BEC5;
    }

    .com_address{
        color: #000 !important;
    }
    .invoice-title {
        text-align: center;
        font-weight: bold;
        font-size: 15px;
        margin-bottom: 15px;
        padding: 5px;
        border-top: 1px dotted #454545;
        border-bottom: 1px dotted #454545;
    }

    .col-xs-12 {
        width: 100%;
    }
    .col-xs-10 {
        width: 80%;
        float: left;
    }
    .col-xs-9 {
        width: 70%;
        float: left;
    }
    .col-xs-7 {
        width: 60%;
        float: left;
    }
    
    .col-xs-6 {
        width: 50%;
        float: left;
    }
    .col-xs-5 {
        width: 40%;
        float: left;
    }
    .col-xs-4 {
        width: 35%;
        float: left;
    }
    .col-xs-3 {
        width: 30%;
        float: left;
    }
    .col-xs-2 {
        width: 20%;
        float: left;
    }
    .b-text {
        font-weight: 500;
        font-size: 15px;
    }
    .normal-text {
        font-size: 14px;
        margin: 0px;
    }
    .invoice-details {
        width: 100%;
        border-collapse: collapse;
        border:1px solid #ccc;
    }
    .invoice-details thead {
        font-weight: 500;
        text-align:center;
    }
    .invoice-details tbody td{
        padding: 0px 5px;
    }
    .text-center {
        text-align: center;
    }
    .text-right {
        text-align: right;
    }
    .line {
        border-bottom: 1px dotted #454545;
        margin-bottom: 15px;
    }
    .paid-text {
        padding:30px 0px;
        
    }
    .mt-60 {
        margin-top: 60px;
    }
    .mr-20 {
        margin-right: 20px;
    }
    .ml-20 {
        margin-left: 20px;
    }
    .ft-fiext {
        position: fixed;
        bottom: 0;
    }
    .cls {
        clear: both;
    }

    @media  print {
        .invoice-title {
            font-size: 16px;
        }
        .com_address h5{
            font-size: 25px;
            
        }
        .com_address p{
            font-size: 16px;
            color: #000;
        }
        .b-text{
            font-size: 16px;
        }
        .normal-text{
            font-size: 16px;
        }

        .invoice-details td{
            font-size: 16px;
        }

        .cus_total table tr td{
            font-size: 16px;
        }
    }
</style>  
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-content'); ?>
<main>
    <div class="container-fluid" id="root">
        <div class="heading-title p-2 my-2">
            <span class="my-3 heading "><i class="fa fa-file-pdf"></i> Customer Oreder Invoice</span>
        </div>
        
        <div class="container">
            <!-- order print-->
            <div class="row ml-1">
                <div class="col-xs-6 mb-2">
                    <span class="print-btn"><a href="" onclick="printDiv('invoiceContent')"><i class="fa fa-print"></i> Print</a></span>
                </div>
            </div>
    
            <div id="invoiceContent">
                <div class="com_content d-flex py-2">
                    <img src="<?php echo e(asset($content->logo)); ?>" class="align-self-center me-2" width="250" height="100" alt="">
                    <div class="com_address">
                        <h5><?php echo e($content->name); ?></h5>
                        <p class="m-0"> <?php echo e($content->address); ?></p>
                        <p class="m-0"><strong>Mobile:</strong> <?php echo e($content->phone); ?></p>
                        <p class="m-0"><strong>Email:</strong> <?php echo e($content->email); ?></p>
                    </div>
                </div>
                
                <div class="custom-row">
                    <div class="invoice-title">
                        Order Invoice
                    </div>
                </div>
                <div class="custom-row">
                    <div class="col-xs-7 cus_address">
                        <strong class="b-text">Customer  Name:</strong> <span class="normal-text"><?php echo e($order->customer->name); ?></span><br>
                        <strong class="b-text">Customer Mobile:</strong> <span class="normal-text"><?php echo e($order->customer->phone); ?></span><br>
                        <strong class="b-text"> Address:</strong> <span class="normal-text"><?php echo e($order->customer->address); ?></span>
                    </div>
                    <div class="col-xs-5 text-right">
                        <strong class="b-text">Invoice No:</strong> <span class="normal-text"><?php echo e($order->invoice_no); ?></span><br>
                        <strong class="b-text">Order Date:</strong> <span class="normal-text"><?php echo e($order->created_at->format('j F Y')); ?></span>
                    </div>
                    <div class="cls"></div>
                </div>
                <div class="custom-row">
                    <div class="line">&nbsp;</div>
                </div>
                <div class="custom-row">
                    <div class="col-xs-12">
                        <table class="invoice-details table-bordered text-center">
                            <thead>
                                <tr>
                                    <td>Sl.</td>
                                    <td>Name</td>
                                    <td>Category</td>
                                    <td>Qty</td>
                                    <td>Price</td>
                                    <td>Total</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($item->product ? $item->product->name : ''); ?></td>
                                    <td><?php echo e($item->product->category->name); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td width="20%"><?php echo e($item->price); ?></td>
                                    <td width="20%" class="text-end"><?php echo e($item->price * $item->quantity); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="custom-row">
                    <div class="col-xs-9">
                        <div class="paid-text">
                            <strong class="b-text">In Words:</strong> <span class="normal-text text-capitalize mr-20" id="words"></span> 
                        </div>
                    </div>
                    <div class="col-xs-3 cus_total">
                        <table width="100%">
                            <tr>
                                <td width="40%" class="b-text">Sub Total :</td>
                                <td class="text-right">$<?php echo e($order->sub_total); ?></td>
                            </tr>
                            <tr>
                                <td width="70%" class="b-text">Shipping Cost:</td>
                                <td class="text-right">$<?php echo e($order->shipping_cost); ?></td>
                            </tr>
                            <tr>
                                <td colspan="2" style="border-bottom: 1px solid rgb(204, 204, 204);"></td>
                            </tr>
                            <tr>
                                <td width="45%" class="b-text">Total:</td>
                                <td class="text-right">$<?php echo e(number_format($order->sub_total + $order->shipping_cost, 2)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }


    var a = ['','one ','two ','three ','four ', 'five ','six ','seven ','eight ','nine ','ten ','eleven ','twelve ','thirteen ','fourteen ','fifteen ','sixteen ','seventeen ','eighteen ','nineteen '];
    var b = ['', '', 'twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety'];

    function inWords (num) {
        if ((num = num.toString()).length > 9) return 'overflow';
        n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) return; var str = '';
        str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
        str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
        str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
        str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
        str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'USD only ' : '';
        return str;
    }
    document.getElementById('words').innerHTML = inWords(<?php echo e($order->sub_total + $order->shipping_cost); ?>);

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/admin/order/invoice.blade.php ENDPATH**/ ?>