
<?php $__env->startSection('title', 'Pending Order'); ?>
<?php $__env->startSection('customer'); ?>
<!-- Customer Dashboard Section here -->
<section style="margin: 40px 0px" id="app">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('pages.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item text-center bg-dark text-white">Shipping Information</li>
                            
                            <li class="list-group-item">
                                <strong>Name:</strong> <?php echo e($order->name); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Phone:</strong>
                                <?php echo e($order->mobile); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Email:</strong>
                                <?php echo e($order->email); ?>

                            </li>
                            
                            <li class="list-group-item">
                                <strong>Order Date:</strong>
                                <?php echo e($order->created_at->format('j F Y')); ?>

                            </li>
                        </ul>
                    </div>

                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item text-center bg-info text-white">Order Information</li>
                            <li class="list-group-item">
                                <strong>Name:</strong> <?php echo e($order->customer->name); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Phone:</strong>
                                <?php echo e($order->customer->phone); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Payment By:</strong>
                                <?php echo e($order->payment_type); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Invoice No:</strong>
                                <?php echo e($order->invoice_no); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Order Total:</strong>
                                $<?php echo e(number_format($order->sub_total, 2)); ?>

                            </li>

                            <li class="list-group-item">
                                <strong>Order Status:</strong>
                                <?php if($order->status == 1): ?>
                                    <span class="badge bg-primary">Confirm</span>
                                <?php elseif($order->status == 2): ?>
                                    <span class="badge bg-info">Process</span>
                                <?php elseif($order->status == 3): ?>
                                    <span class="badge bg-warning">Shipping</span>
                                <?php elseif($order->status == 4): ?>
                                    <span class="badge bg-success">Delivered</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Cancel</span>
                                <?php endif; ?>

                            </li>
                        </ul>
                    </div>
                </div>

                <div class="row">
                    <div class="customer_profile table-responsive mt-2">
                
                        <table class="table table-bordered table-hover text-center">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
    
                            <tbody>
                                <?php $__currentLoopData = $orderItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><img src="<?php echo e(asset($item->product->image)); ?>" height="30px;" width="30px;" alt="imga"></td>
                                    <td><?php echo e($item->product->name); ?></td>
                                    <td><?php echo e($item->product->category->name); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e(number_format($item->price, 2)); ?></td>
                                    <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="6" class="text-end"><strong>Sub Total:</strong></td>
                                    <td><strong>$<?php echo e(number_format($order->sub_total, 2)); ?></strong></td>
                                </tr>
                                <tr>
                                    <td colspan="6" class="text-end"><strong>Shipping Charge:</strong></td>
                                    <td><strong>$<?php echo e(number_format($order->shipping_cost, 2)); ?></strong></td>
                                </tr>
                                <tr>
                                    <td colspan="6" class="text-end"><strong>Total Amount:</strong></td>
                                    <td><strong>$<?php echo e(number_format($order->sub_total + $order->shipping_cost, 2)); ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.customer.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\author\resources\views/pages/customer/order_details.blade.php ENDPATH**/ ?>